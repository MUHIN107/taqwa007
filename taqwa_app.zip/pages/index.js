
export default function Home() {
    return (
        <div className="min-h-screen bg-gradient-to-b from-green-100 to-white text-gray-800 p-4">
            <header className="text-center py-6">
                <h1 className="text-3xl font-bold text-green-700">🕌 TAQWA</h1>
                <p className="text-lg">আসসালামু আলাইকুম!</p>
            </header>
            <main className="max-w-xl mx-auto space-y-6">
                <section className="bg-white rounded-2xl shadow p-4 border border-green-200">
                    <h2 className="text-xl font-semibold text-green-700 mb-2">📿 আজকের রিমাইন্ডার</h2>
                    <p className="text-gray-700 italic">
                        “আর যারা আল্লাহর পথে নিহত হয়েছে, তুমি তাদের মৃত বলো না; বরং তারা জীবিত, কিন্তু তুমি তা উপলব্ধি করো না।” 
                    </p>
                    <p className="text-right mt-2 text-sm text-gray-500">— সূরা আল-বাকারা: ১৫৪</p>
                </section>
                <section className="grid grid-cols-1 gap-4">
                    <button className="bg-green-600 text-white rounded-2xl py-3 px-5 shadow hover:bg-green-700 transition">
                        📝 নতুন পোস্ট করুন
                    </button>
                    <button className="bg-white border border-green-300 text-green-700 rounded-2xl py-3 px-5 shadow hover:bg-green-100 transition">
                        📖 প্রিয় দোয়া
                    </button>
                    <button className="bg-white border border-green-300 text-green-700 rounded-2xl py-3 px-5 shadow hover:bg-green-100 transition">
                        👥 আমার কমিউনিটি
                    </button>
                </section>
            </main>
            <footer className="text-center mt-10 text-sm text-gray-500">
                TAQWA – আল্লাহভীরু জীবনের পথে
            </footer>
        </div>
    );
}
